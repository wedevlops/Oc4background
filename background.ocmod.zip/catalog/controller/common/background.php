<?php
class ControllerCommonBackground extends Controller {
  public function index() {
    $this->load->language('common/background');

    $data['background_image'] = $this->config->get('background_image');

    return $this->load->view('common/background', $data);
  }
}
